// ==UserScript==
// @name        E-hentai: Auto click Expunged & Description
// @namespace   autoclick-ehentai
// @description Auto Click on Show Expunged Galleries and Search Gallery Description
// @copyright   playguitar103
// @version     1.2.1
// @homepageURL https://greasyfork.org/es/scripts/378159-e-hentai-auto-click-expunged-description
// @run-at      document-end
// @require     https://code.jquery.com/jquery-1.2.1.pack.js
// @include     https://exhentai.org/*
// @include     https://e-hentai.org/*
// @exclude     https://exhentai.org/g/*
// @exclude     https://exhentai.org/s/*
// @exclude     https://e-hentai.org/g/*
// @exclude     https://e-hentai.org/s/*
// ==/UserScript==

var aqui=$("#searchbox a:contains('Show Advanced Options')");
function inputs(){
    document.getElementById('adv31').checked = true;
    document.getElementById('adv13').checked = true;
};
function actualizar_pag(){
    $('input[value="Apply Filter"]')[0].click();
};
if(aqui[0]){
    aqui[0].click();
    window.setTimeout(inputs, 100);
    window.setTimeout(actualizar_pag, 200);
}